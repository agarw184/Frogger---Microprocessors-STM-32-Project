//typedef struct vehicle {
//    int position[2];  // x,y position
//    int vtype;  // 0 for car, 1 for truck
//    int delay;  // how much lag time on rows
//    int direction;  // 1 for right, -1 for left
//    uint16_t color;
//    int count;
//} vehicle;
//
//vehicle vlist[128];

void setup_array();
void setupDisplay();
void setup_GPIO();
void toggleClock();
void setup_timer6();
void TIM6_DAC_IRQHandler();
void draw_pixel(int row, int column, uint16_t color);
void draw_frog();
void drawCar(int x, int y, uint16_t color);
void manageCount();
void handleArrs(int index);

bool arr1 [] = {0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,0};
bool arr2 [] = {1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0};
bool arr3 [] = {0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0};
bool arr4 [] = {0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0};
bool arr5 [] = {0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
bool arr6 [] = {0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0};
bool arr7 [] = {0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0};
bool arr8 [] = {0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0};

