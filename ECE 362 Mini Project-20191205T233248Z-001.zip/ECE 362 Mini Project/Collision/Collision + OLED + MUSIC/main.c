#include "stm32f0xx.h"
#include "stm32f0_discovery.h"
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include "objects.h"
#include "pitches.h"



// YOU CANNOT USE THESE VALUES FOR GPIO_MODER as two bits represent one MODER port.
#define MATRIX_R1   0x1 //PC0
#define MATRIX_G1   0x2 //PC1
#define MATRIX_B1   0x4 //PC2
#define MATRIX_R2   0x8 //PC3
#define MATRIX_G2   0x10   //PC4
#define MATRIX_B2   0x20   //PC5
#define MATRIX_A    0x40   //PC6
#define MATRIX_B    0x80   //PC7
#define MATRIX_C    0x400  //PC10
#define MATRIX_D    0x800  //PC11
#define MATRIX_CLK  0x2000 //PC13
#define MATRIX_LAT  0x4000 //PC14
#define MATRIX_OE   0x1000 //PC12
#define MATRIX_LEDS 0x3F   //PC0-PC5
#define MATRIX_ROWS 0xCC0  //PC6, 7, 10, 11
#define N 750


int offset;
int step;
int counter = 0;

short int wavetable[N];



void init_wavetable(void)
{
  int x;
  for(x=0; x<N; x++)
    wavetable[x] = 32767 * sin(2 * M_PI * x / N);
}

int reachedTop = 0;

void reached_top(int);

void (*cmd)(char b) = 0;
void (*data)(char b) = 0;
void (*display1)(const char *) = 0;
void (*display2)(const char *) = 0;
extern int count;
int isCirc;


void gameStartOLED(void);
//void step3(void);
void staticDisp(const char *);
void generic_lcd_startup(void);

uint16_t dispmem[34] = {
        0x080 + 0,
        0x220, 0x220, 0x220, 0x220, 0x220, 0x220, 0x220, 0x220,
        0x220, 0x220, 0x220, 0x220, 0x220, 0x220, 0x220, 0x220,
        0x080 + 64,
        0x220, 0x220, 0x220, 0x220, 0x220, 0x220, 0x220, 0x220,
        0x220, 0x220, 0x220, 0x220, 0x220, 0x220, 0x220, 0x220,
};


void spi_cmd(char b) {
   while ((SPI2-> SR & SPI_SR_TXE) == 0);
   (SPI2 -> DR) = b;
}

void spi_data(char b)
{

  while ((SPI2-> SR & SPI_SR_TXE) == 0);
  (SPI2 -> DR) = 0x200 + b;
}

void circdma_display1(const char *s) {
       int x;
       for(x=0; x<16; x+=1)
           if (s[x])
               dispmem[x+1] = 0x200 + s[x];
           else
               break;
       for(   ; x<16; x+=1)
         dispmem[x+1] = 0x220;



}

void circdma_display2(const char *s) {
  cmd(0x80 + 0);
       int x;
       for(x=0; x<16; x+=1)
           if (s[x])
               dispmem[x+18] = 0x200 + s[x];
           else
               break;
       for(   ; x<16; x+=1)
         dispmem[x+1] = 0x220;

}

void dma_spi_init_lcd(int isCirc) {
    spi_init_lcd();

    //Set appropriate DMA channel
    RCC -> AHBENR |= RCC_AHBENR_DMA1EN;
    DMA1_Channel5-> CCR &= ~DMA_CCR_EN;             //turn off enable
    DMA1_Channel5-> CMAR = (uint32_t) dispmem;      //memory
    DMA1_Channel5-> CPAR = (uint32_t) &(SPI2->DR);  //peripheral
    DMA1_Channel5 -> CNDTR = 34;                    //34 words
    DMA1_Channel5-> CCR |= DMA_CCR_DIR;             //from mem
    DMA1_Channel5 ->CCR &= ~DMA_CCR_MSIZE;
    DMA1_Channel5 ->CCR |= DMA_CCR_MSIZE_0;         //memory size
    DMA1_Channel5 ->CCR &= ~DMA_CCR_PSIZE;
    DMA1_Channel5 ->CCR |= DMA_CCR_PSIZE_0;   //peripheral size
    DMA1_Channel5 ->CCR |= DMA_CCR_MINC;      //increment memory
    DMA1_Channel5 ->CCR &= ~DMA_CCR_PL;       //low priority
    if (isCirc)
    {
        DMA1_Channel5 ->CCR |= DMA_CCR_CIRC;      //circular mode
    }
    SPI2 -> CR2 |= SPI_CR2_TXDMAEN;
    DMA1_Channel5 -> CCR |= DMA_CCR_EN;

}


void spi_init_lcd(void)
{
    // PB12,13,15
    RCC -> AHBENR |= RCC_AHBENR_GPIOBEN;
    GPIOB -> MODER &= ~0xCF000000;
    GPIOB -> MODER |= 0x8A000000;
    GPIOB -> AFR[1] &= ~0xF0FF0000;

    RCC -> APB1ENR |= RCC_APB1ENR_SPI2EN;
    SPI2 -> CR1 |= SPI_CR1_MSTR;
    //SPI2 -> CR1 |= SPI_CR1_BR_0 | SPI_CR1_BR_1 | SPI_CR1_BR_2;  //fclock/(256)
    SPI2 -> CR1 |= SPI_CR1_BR_1 | SPI_CR1_BR_2;         // f/128 is fastest //find highest baud rate that works
    SPI2 -> CR1 |= SPI_CR1_BIDIMODE | SPI_CR1_BIDIOE;
    SPI2 -> CR1 &= ~SPI_CR1_CPOL; //0: 0 when idle
    SPI2 -> CR1 &= ~SPI_CR1_CPHA; //0: first clock transition is first data capture edge
    SPI2 -> CR2 = SPI_CR2_SSOE | SPI_CR2_NSSP | SPI_CR2_DS_3 | SPI_CR2_DS_0;   //1001
    SPI2 -> CR1 |= SPI_CR1_SPE;

    generic_lcd_startup();
}

bool  game_over[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,1,1,0,1,1,1,1,0,1,1,0,1,1,0,1,1,1,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,1,1,0,1,1,1,1,0,1,0,1,0,1,0,1,1,1,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,0,1,0,1,0,1,0,1,1,1,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,1,1,1,0,1,0,0,1,0,1,1,1,1,0,1,1,1,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,0,1,1,1,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,0,0,1,0,1,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,1,1,1,0,0,1,1,0,0,1,1,1,1,0,1,0,0,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

bool  homescreen[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0,1,0,1,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,1,0,1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,1,0,1,1,1,0,1,1,1,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,0,0,1,0,0,0,1,0,1,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,1,0,1,1,1,0,1,0,1,0,1,1,1,0,0,1,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,1,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,1,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,1,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};


int button_up =50;
int button_right=50;
int button_left =50;

uint16_t pixeldisplay[33][32];
int pos_frog[2];
int count = 0;

const char *msg2 = "          PRESS UP BUTTON TO PLAY ";
int offset = 0;
int main(void)
{
    init_wavetable();
    setup_GPIO();
    setup_dac();
    setup_timer6();
    setup_timer15();

    setup_array();
    pos_frog[0] = 30;
    pos_frog[1] =15;
    draw_frog(30,15);
    setup_gpio_buttons();
    setup_timer3();
    setup_timer2();
    gameStartOLED();

    //enable_exti1_0();
    //enable_exti2();
    //gameover();

    while(1)
    {
        setupDisplay();
    }
}
void moveV(vehicle v, int* position[2], uint16_t color, int direction, int type) {
    int size = 3;
//    if(type == 1) {
//        size = 3;
//    } else {
//        size = 2;
//    }
    drawVehicle_truck(v.position, color);
    int temp[2];
    temp[0] = v.position[0];
    temp[1] = v.position[1] - size;
    drawVehicle_truck(temp, 0);
}
vehicle new;
void setup_timer2() {
    RCC -> APB1ENR |= RCC_APB1ENR_TIM2EN;
    TIM2 -> CR1 &= ~TIM_CR1_CEN;
    TIM2 -> ARR = 1000 - 1;
    TIM2 -> PSC = 10000- 1;
    TIM2 -> DIER |= TIM_DIER_UIE;
    NVIC -> ISER[0] = 1 << TIM2_IRQn;
    TIM2 -> CR1 |= TIM_CR1_CEN;
    count = 0;
}
void TIM2_IRQHandler() {
new.vtype=1;
TIM2 -> SR &= ~TIM_SR_UIF;
if(count < 33) {
        new.position[0] =27;
        new.position[1] =-2 + count;
        moveV(new, new.position, MATRIX_B2, 1, 0);
        count++;
    }
else {
        count = 0;
        drawVehicle_truck(new.position, 0);
    }
}

void drawVehicle_car(int position[2], uint16_t color){
                //row        column
    if(check_collision_car(position[0], position[1] ))
       {
       TIM2 -> CR1 &= ~TIM_CR1_CEN;
       gameover();
       pos_frog[0] = 30;
       pos_frog[1] =15;
       draw_frog(30,15);
       return;
       }
    draw_pixel(position[0], position[1], color);
    draw_pixel(position[0] + 1, position[1], color);
    draw_pixel(position[0], position[1] + 1, color);
    draw_pixel(position[0] + 1, position[1] + 1, color);
}

void drawVehicle_truck(int position[2], uint16_t color){
                //row        column
    if(check_collision_truck(position[0], position[1] ))
       {
       TIM2 -> CR1 &= ~TIM_CR1_CEN;
       gameover();
       pos_frog[0] = 30;
       pos_frog[1] =15;
       draw_frog(30,15);
       return;
       }
    draw_pixel(position[0], position[1], color);
    draw_pixel(position[0] + 1, position[1], color);
    draw_pixel(position[0] + 1, position[1] + 2, color);
    draw_pixel(position[0], position[1] + 2, color);
    draw_pixel(position[0], position[1] + 1, color);
    draw_pixel(position[0] + 1, position[1] + 1, color);
}
void setup_GPIO() {
    RCC->AHBENR |= RCC_AHBENR_GPIOCEN;
    GPIOC->MODER &= ~0x3FF0FFFF; // We are using all PC pins except for 8,9,15
    GPIOC->MODER |= (0x15505555);
    GPIOC->PUPDR = (GPIOC->PUPDR & 0xC00F0000) | 0x15505555;
    GPIOC -> BSRR |= (0x7CFF<<16);

    RCC->AHBENR |= RCC_AHBENR_GPIOAEN;
    GPIOA->MODER |= 3 << (4*2);

}

void setup_dac()
{
    RCC->APB1ENR |= RCC_APB1ENR_DACEN;
    DAC->CR &= ~DAC_CR_EN1;
    DAC->CR &= ~DAC_CR_BOFF1;
    DAC->SWTRIGR |= DAC_SWTRIGR_SWTRIG1;
    DAC->CR |= DAC_CR_TEN1;
    DAC->CR |= DAC_CR_TSEL1;
    DAC->CR |= DAC_CR_EN1;
}

void setup_timer6()
{
    RCC->APB1ENR |= RCC_APB1ENR_TIM6EN;
    TIM6->ARR = 9;                  //400 hz
    TIM6->PSC = 100-1;
    TIM6->DIER |= TIM_DIER_UIE;
    TIM6->CR1 |= TIM_CR1_CEN;
    NVIC->ISER[0] = 1<<TIM6_DAC_IRQn;
}

void TIM6_DAC_IRQHandler()
{
    DAC->SWTRIGR |= DAC_SWTRIGR_SWTRIG1;
    TIM6->SR &= ~TIM_SR_UIF;
    offset += step;

    if ((offset>>16) >= N)
        offset -= N<<16;

    int sample = 0;
    sample = wavetable[offset>>16];

    sample = sample / 16 + 2048;
    if (sample > 4095) sample = 4095;
    else if (sample < 0) sample = 0;

    DAC->DHR12R1 = sample;

}

void setup_timer15()
{
    RCC->APB2ENR |= RCC_APB2ENR_TIM15EN;
    TIM15->PSC = 2000-1;
    TIM15->ARR = 1000-1;
    TIM15->DIER |= TIM_DIER_UIE;
    TIM15->CR1 |= TIM_CR1_CEN;
    NVIC->ISER[0] = 1<<TIM15_IRQn;
}

void playnote(int freq)
{
    step = freq * N / 100000.0 * (1 << 16);
}

void TIM15_IRQHandler()
{
    TIM15->SR &= ~TIM_SR_UIF;

    switch(counter)
    {
    case 0:

    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
        playnote(NOTE_E4);

        break;

    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
        playnote(NOTE_B3);
        break;

    case 15:
    case 16:
    case 17:
    case 18:
    case 19:
        playnote(NOTE_C4);
        break;

    case 20:
    case 21:
    case 22:
    case 23:
    case 24:
    case 25:
    case 26:
    case 27:
    case 28:
    case 29:
        playnote(NOTE_D4);
        break;

    case 30:
    case 31:
    case 32:
    case 33:
    case 34:
        playnote(NOTE_C4);
        break;

    case 35:
    case 36:
    case 37:
    case 38:
    case 39:
        playnote(NOTE_B3);
        break;

    case 40:
    case 41:
    case 42:
    case 43:
    case 44:
    case 45:
    case 46:
    case 47:
    case 48:
    case 49:
        playnote(NOTE_A3);
        break;

    case 50:
        playnote(0);
        break;

    case 51:
    case 52:
    case 53:
    case 54:
    case 55:
        playnote(NOTE_A3);
        break;

    case 56:
    case 57:
    case 58:
    case 59:
    case 60:
        playnote(NOTE_C4);
        break;

   case 61:
   case 62:
   case 63:
   case 64:
   case 65:
   case 66:
   case 67:
   case 68:
   case 69:
   case 70:
       playnote(NOTE_E4);
       break;

   case 71:
   case 72:
   case 73:
   case 74:
   case 75:
       playnote(NOTE_D4);
       break;

   case 76:
   case 77:
   case 78:
   case 79:
   case 80:
       playnote(NOTE_C4);
       break;

   case 81:
   case 82:
   case 83:
   case 84:
   case 85:
   case 86:
   case 87:
   case 88:
   case 89:
   case 90:
   case 91:
   case 92:
   case 93:
   case 94:
   case 95:
       playnote(NOTE_B3);
       break;

   case 96:
   case 97:
   case 98:
   case 99:
   case 100:
       playnote(NOTE_C4);
       break;

   case 101:
   case 102:
   case 103:
   case 104:
   case 105:
   case 106:
   case 107:
   case 108:
   case 109:
   case 110:
       playnote(NOTE_D4);
       break;

   case 111:
   case 112:
   case 113:
   case 114:
   case 115:
   case 116:
   case 117:
   case 118:
   case 119:
   case 120:
       playnote(NOTE_E4);
       break;

   case 121:
   case 122:
   case 123:
   case 124:
   case 125:
   case 126:
   case 127:
   case 128:
   case 129:
   case 130:
       playnote(NOTE_C4);
       break;

   case 131:
   case 132:
   case 133:
   case 134:
   case 135:
   case 136:
   case 137:
   case 138:
   case 139:
   case 140:
       playnote(NOTE_A3);
       break;

   case 141:
       playnote(0);
       break;

   case 142:
   case 143:
   case 144:
   case 145:
   case 146:
   case 147:
   case 148:
   case 149:
   case 150:
   case 151:
   case 152:
   case 153:
   case 154:
   case 155:
   case 156:
   case 157:
   case 158:
   case 159:
   case 160:
   case 161:
       playnote(NOTE_A3);
       break;

   case 162:
   case 163:
   case 164:
   case 165:
   case 166:
       playnote(NOTE_C4);
       break;

   case 167:
   case 168:
   case 169:
   case 170:
   case 171:
   case 172:
   case 173:
   case 174:
   case 175:
   case 176:
      playnote(NOTE_E4);
      break;

   case 177:
   case 178:
   case 179:
   case 180:
   case 181:
     playnote(NOTE_D4);
     break;

   case 182:
   case 183:
   case 184:
   case 185:
   case 186:
       playnote(NOTE_C4);
       break;

   case 187:
   case 188:
   case 189:
   case 190:
   case 191:
   case 192:
   case 193:
   case 194:
   case 195:
   case 196:
   case 197:
   case 198:
   case 199:
   case 200:
   case 201:
       playnote(NOTE_B3);
       break;

   case 202:
   case 203:
   case 204:
   case 205:
   case 206:
       playnote(NOTE_C4);
       break;

   case 207:
   case 208:
   case 209:
   case 210:
   case 211:
   case 212:
   case 213:
   case 214:
   case 215:
   case 216:
       playnote(NOTE_D4);
       break;

   case 217:
   case 218:
   case 219:
   case 220:
   case 221:
   case 222:
   case 223:
   case 224:
   case 225:
   case 226:
       playnote(NOTE_E4);
       break;

   case 227:
   case 228:
   case 229:
   case 230:
   case 231:
   case 232:
   case 233:
   case 234:
   case 235:
   case 236:
       playnote(NOTE_C4);
       break;

   case 237:
   case 238:
   case 239:
   case 240:
   case 241:
   case 242:
   case 243:
   case 244:
   case 245:
   case 246:
       playnote(NOTE_A3);
       break;

   case 247:
   case 248:
   case 249:
   case 250:
   case 251:
   case 252:
   case 253:
   case 254:
   case 255:
   case 256:
   case 257:
   case 258:
   case 259:
   case 260:
   case 261:
   case 262:
   case 263:
   case 264:
   case 265:
   case 266:
       playnote(NOTE_A3);
       break;

   case 267:  //???
       playnote(0);
       break;

   case 268:
   case 269:
   case 270:
   case 271:
   case 272:
   case 273:
   case 274:
   case 275:
   case 276:
   case 277:
       playnote(NOTE_D4);
       break;

   case 278:
   case 279:
   case 280:
   case 281:
   case 282:
       playnote(NOTE_F4);
       break;

   case 283:
   case 284:
   case 285:
   case 286:
   case 287:
   case 288:
   case 289:
   case 290:
   case 291:
   case 292:
       playnote(NOTE_A4);
       break;

   case 293:
   case 294:
   case 295:
   case 296:
   case 297:
       playnote(NOTE_G4);
       break;

   case 298:
   case 299:
   case 300:
   case 301:
   case 302:
       playnote(NOTE_F4);
       break;

   case 303:
   case 304:
   case 305:
   case 306:
   case 307:
   case 308:
   case 309:
   case 310:
   case 311:
   case 312:
   case 313:
   case 314:
   case 315:
   case 316:
   case 317:
       playnote(NOTE_E4);
       break;

   case 318:
   case 319:
   case 320:
   case 321:
   case 322:
       playnote(NOTE_C4);
       break;

   case 323:
   case 324:
   case 325:
   case 326:
   case 327:
   case 328:
   case 329:
   case 330:
   case 331:
   case 332:
       playnote(NOTE_E4);
       break;

   case 333:
   case 334:
   case 335:
   case 336:
   case 337:
       playnote(NOTE_D4);
       break;

   case 338:
   case 339:
   case 340:
   case 341:
   case 342:
       playnote(NOTE_C4);
       break;

   case 343:
   case 344:
   case 345:
   case 346:
   case 347:
   case 348:
   case 349:
   case 350:
   case 351:
   case 352:
       playnote(NOTE_B3);
       break;

   case 353:
   case 354:
   case 355:
   case 356:
   case 357:
       playnote(NOTE_B3);
       break;

   case 358:
   case 359:
   case 360:
   case 361:
   case 362:
       playnote(NOTE_C4);
       break;

   case 363:
   case 364:
   case 365:
   case 366:
   case 367:
   case 368:
   case 369:
   case 370:
   case 371:
   case 372:
       playnote(NOTE_D4);
       break;

   case 373:
   case 374:
   case 375:
   case 376:
   case 377:
   case 378:
   case 379:
   case 380:
   case 381:
   case 382:
       playnote(NOTE_E4);
       break;

   case 383:
   case 384:
   case 385:
   case 386:
   case 387:
   case 388:
   case 389:
   case 390:
   case 391:
   case 392:
       playnote(NOTE_C4);
       break;

   case 393:
   case 394:
   case 395:
   case 396:
   case 397:
   case 398:
   case 399:
   case 400:
   case 401:
   case 402:
       playnote(NOTE_A3);
       break;

   case 403:
   case 404:
   case 405:
   case 406:
   case 407:
   case 408:
   case 409:
   case 410:
   case 411:
   case 412:
   case 413:
   case 414:
   case 415:
   case 416:
   case 417:
   case 418:
   case 419:
   case 420:
   case 421:
   case 422:
       playnote(NOTE_A3);
       counter = -1;
       break;
    }
    counter++;
}



void setup_array() {
    for(int i=0; i < 33; i++) {
        for(int j=0; j < 32; j++) {
            if((i == 1)) {
                pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_G1);
            }
            else if((i == 0) | (i == 33)){
                if(i == 0) {

                        pixeldisplay[i][j] = MATRIX_R1;
                } else {
                    pixeldisplay[i][j] = MATRIX_R2;
                }
            }
            else if(i == 15) {
                pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_B1);
            }
            else if((i == 16) | (i== 30) | (i== 31)){
                pixeldisplay[i][j] = (MATRIX_R2 | MATRIX_B2);
            }
            else {
                pixeldisplay[i][j] = 0;
            }
        }
    }

}

void setupDisplay() {
    int row = 0;
    GPIOC -> BRR |= (MATRIX_CLK|MATRIX_LAT|MATRIX_OE);
    for(int i = 0; i < 33; i++) {
        for(int j = 0; j < 32; j++) {
          GPIOC ->BRR  |= MATRIX_LEDS;
          GPIOC->BSRR |= pixeldisplay[i][j];
          toggleClock();
          toggleClock();
        }
        if(i >= 16) {
            row = i - 16;
        } else {
            row = i;
        }
        GPIOC-> BSRR |= MATRIX_OE;
        GPIOC-> BSRR = (MATRIX_ROWS<<16);
        GPIOC-> BSRR |= (((row & 0x1) << 6)|(((row >> 1) & 0x1) << 7)|(((row >> 2) & 0x1) << 10)|(((row >> 3) & 0x1) << 11));
        GPIOC-> BSRR |= MATRIX_LAT;
        GPIOC-> BRR |= MATRIX_LAT;
        GPIOC-> BRR |= MATRIX_OE;
        GPIOC ->BRR  |= MATRIX_LEDS;
    }
}

void toggleClock() {
    if((GPIOC->ODR & MATRIX_CLK)>>13) {
        GPIOC->BSRR |= (MATRIX_CLK<<16);
    } else {
        GPIOC->BSRR |= MATRIX_CLK;
    }
    return;
}

void draw_pixel(int row, int column, uint16_t color) {
    if((row<0) | (column<0) | (row>32) | (column>31)){
        return;
    }
    pixeldisplay[row][column] = color;
}

void setup_gpio_buttons()
{
    //PB0, PB1, PB2 configured as input
    RCC -> AHBENR |= RCC_AHBENR_GPIOBEN;
    GPIOB -> MODER &= ~(GPIO_MODER_MODER0); //PB0 -> Left
    GPIOB -> MODER &= ~(GPIO_MODER_MODER1); //PB1 -> Up
    GPIOB -> MODER &= ~(GPIO_MODER_MODER2); //PB5 -> Right
    GPIOB->PUPDR &= ~(GPIO_PUPDR_PUPDR0|GPIO_PUPDR_PUPDR0|GPIO_PUPDR_PUPDR0);
    GPIOB->PUPDR |= (GPIO_PUPDR_PUPDR0_0|GPIO_PUPDR_PUPDR1_0|GPIO_PUPDR_PUPDR2_0);

}
void move_up()
{
    if(check_collision_frog(pos_frog[0]-1,pos_frog[1]))
         {
         TIM2 -> CR1 &= ~TIM_CR1_CEN;
         gameover();
         pos_frog[0] = 30;
         pos_frog[1] =15;
         draw_frog(30,15);
         return;
         }
    draw_frog(pos_frog[0]-1,pos_frog[1]);
    //check if on top most row
    if (pos_frog[0] == 0)
    {
        reachedTop++;
        reached_top(reachedTop);
        setup_array();
        pos_frog[0] = 30;
        pos_frog[1] = 15;
        draw_frog(30,15);

        //reset the oled display and increase prescalar for cars

    }

}

void reached_top(int reachedTop)
{
    //print next level to oled
    switch (reachedTop)
    {
        case 2:
            staticDisp("  Level: 2");
            break;
        case 3:
            staticDisp("  Level: 3");
            break;
        case 4:
            staticDisp("  Level: 4");
            break;
        case 5:
            staticDisp("  Level: 5");
            break;
        case 6:
            staticDisp("  Level: 6");
            break;
        case 7:
            staticDisp("  Level: 7");
            break;
        case 8:
            staticDisp("  Level: 8");
            break;
        case 9:
            staticDisp("  Level: 9");
            break;

        default:
            staticDisp("  Level: 1");
            break;
    }
}


void move_left()
{
    if(check_collision_frog(pos_frog[0],pos_frog[1]-1))
       {
       TIM2 -> CR1 &= ~TIM_CR1_CEN;
       gameover();
       pos_frog[0] = 30;
       pos_frog[1] =15;
       draw_frog(30,15);
       return;
       }
    draw_frog(pos_frog[0],pos_frog[1]-1);
}

void move_right()
{
    if(check_collision_frog(pos_frog[0], pos_frog[1]+1))
    {
    TIM2 -> CR1 &= ~TIM_CR1_CEN;
    gameover();
    pos_frog[0] = 30;
    pos_frog[1] =15;
    draw_frog(30,15);
    return;
    }
    draw_frog(pos_frog[0], pos_frog[1]+1);

}

void draw_frog(int row, int column)
{
    if((row<0) | (column<0) | (row>30) | (column>30)){
              return;
          }

    draw_pixel(pos_frog[0],pos_frog[1],0);
    draw_pixel(pos_frog[0]+1,pos_frog[1],0);
    draw_pixel(pos_frog[0]+1,pos_frog[1]+1,0);
    draw_pixel(pos_frog[0],pos_frog[1]+1,0);

    if(pos_frog[0] == 15)
    {   draw_pixel(pos_frog[0],pos_frog[1],MATRIX_B1|MATRIX_R1);
        draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_B1|MATRIX_R1);
    }
    else if(pos_frog[0]== 16 || pos_frog[0]== 30 || pos_frog[0]== 31)
    {
        draw_pixel(pos_frog[0],pos_frog[1],MATRIX_B2|MATRIX_R2);
        draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_B2|MATRIX_R2);

    }
    else if(pos_frog[0]==0)
   {
           draw_pixel(pos_frog[0],pos_frog[1],MATRIX_R1);
           draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_R1);

   }

    else if(pos_frog[0]==1)
      {
                draw_pixel(pos_frog[0],pos_frog[1],MATRIX_R1|MATRIX_G1);
                draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_R1|MATRIX_G1);

       }
     if (pos_frog[0]+ 1 == 15 )
    {
    draw_pixel(pos_frog[0]+1,pos_frog[1],MATRIX_B1|MATRIX_R1);
    draw_pixel(pos_frog[0]+1,pos_frog[1]+1,MATRIX_B1|MATRIX_R1);
    }

    else if(pos_frog[0]+ 1 == 16 || pos_frog[0]+ 1 == 30 || pos_frog[0]+ 1 == 31)
    {
        draw_pixel(pos_frog[0]+1,pos_frog[1],MATRIX_B2|MATRIX_R2);
        draw_pixel(pos_frog[0]+1,pos_frog[1]+1,MATRIX_B2|MATRIX_R2);

    }


    else if(pos_frog[0]+1==1)
    {
           draw_pixel(pos_frog[0]+1,pos_frog[1],MATRIX_R1|MATRIX_G1);
           draw_pixel(pos_frog[0]+1,pos_frog[1]+1,MATRIX_R1|MATRIX_G1);

     }

    if(row < 15)
    {
       draw_pixel(row,column,MATRIX_G1);
       draw_pixel(row+1,column,MATRIX_G1);
       draw_pixel(row,column+1,MATRIX_G1);
       draw_pixel(row+1,column+1,MATRIX_G1);
    }
    else if(row == 15)
    {
        draw_pixel(row,column+1,MATRIX_G1);
        draw_pixel(row,column,MATRIX_G1);
        draw_pixel(row+1,column,MATRIX_G2);
        draw_pixel(row+1,column+1,MATRIX_G2);
    }

    else
    {
        draw_pixel(row,column,MATRIX_G2);
        draw_pixel(row+1,column,MATRIX_G2);
        draw_pixel(row,column+1,MATRIX_G2);
        draw_pixel(row+1,column+1,MATRIX_G2);
    }
    pos_frog[0] = row;
    pos_frog[1] = column;
}

void setup_timer3() {
    /* Student code goes here */
     RCC ->APB1ENR |= RCC_APB1ENR_TIM3EN;
     TIM3->ARR = 200 - 1;
     TIM3->PSC = 1200 - 1;
     TIM3->DIER |= TIM_DIER_UIE;
     TIM3 ->CR1 |= TIM_CR1_CEN;
     NVIC->ISER[0] = 1<<TIM3_IRQn;

}

int check_collision_frog(int row,int  column)
{
    if((row<0) | (column<0) | (row>30) | (column>30)){
                  return 0;
              }
    if(row <=15)
    {
        if(pixeldisplay[row][column] == MATRIX_B1|pixeldisplay[row+1][column] == MATRIX_B1| pixeldisplay[row][column+1] == MATRIX_B1|pixeldisplay[row+1][column+1] == MATRIX_B1)
            return 1;
        else if(pixeldisplay[row][column] == (MATRIX_B1|MATRIX_G1)|pixeldisplay[row+1][column] == (MATRIX_B1|MATRIX_G1)|pixeldisplay[row][column+1] == (MATRIX_B1|MATRIX_G1)|pixeldisplay[row+1][column+1] == (MATRIX_B1|MATRIX_G1))
            return 1;
        else
            return 0;
    }

    else
    {
        if(pixeldisplay[row][column] == MATRIX_B2|pixeldisplay[row+1][column] == MATRIX_B2| pixeldisplay[row][column+1] == MATRIX_B2|pixeldisplay[row+1][column+1] == MATRIX_B2)
                   return 1;
               else if(pixeldisplay[row][column] == (MATRIX_B2|MATRIX_G2)|pixeldisplay[row+1][column] == (MATRIX_B2|MATRIX_G2)|pixeldisplay[row][column+1] == (MATRIX_B2|MATRIX_G2)|pixeldisplay[row+1][column+1] == (MATRIX_B2|MATRIX_G2))
                   return 1;
               else
                   return 0;

    }
}

int check_collision_car(int row,int  column)
{
    if(column == -1 && row <=15){
        if(pixeldisplay[row][column+1] == MATRIX_G1 |pixeldisplay[row+1][column+1] == MATRIX_G1)
                       return 1;
             else
                return 0;

    }
    else if(column == -1 && row >15)
    {
        if(pixeldisplay[row][column+1] == MATRIX_G2 |pixeldisplay[row+1][column+1] == MATRIX_G2)
                             return 1;
                   else
                      return 0;

    }

    else if(column == 31  && row <=15)
    {
        if(pixeldisplay[row][column] == MATRIX_G1|pixeldisplay[row+1][column] == MATRIX_G1)
                                   return 1;
                         else
                            return 0;


    }

    else if(column ==31 && row >15)
    {
        if(pixeldisplay[row][column] == MATRIX_G2|pixeldisplay[row+1][column] == MATRIX_G2)
                              return 1;
                    else
                       return 0;


    }
    else if((row<0) | (row>30) | (column>31)|(column <-1))
    {
                  return 0;
              }

    else if(row <=15)
    {
        if(pixeldisplay[row][column] == MATRIX_G1|pixeldisplay[row+1][column] == MATRIX_G1| pixeldisplay[row][column+1] == MATRIX_G1|pixeldisplay[row+1][column+1] == MATRIX_G1)
                   return 1;
         else
            return 0;
    }

    else
    {
        if(pixeldisplay[row][column] == MATRIX_G2|pixeldisplay[row+1][column] == MATRIX_G2| pixeldisplay[row][column+1] == MATRIX_G2|pixeldisplay[row+1][column+1] == MATRIX_G2)
                   return 1;
        else
                   return 0;

    }
}

int check_collision_truck(int row,int  column)
{   if (column == -2 && row <=15){
    if(pixeldisplay[row][column+2] == MATRIX_G1|pixeldisplay[row+1][column+2] == MATRIX_G1)
                         return 1;
               else
                  return 0;

   }
else if(column == -2 && row >15){
    if(pixeldisplay[row][column+2] == MATRIX_G2|pixeldisplay[row+1][column+2] == MATRIX_G2)
                         return 1;
               else
                  return 0;

   }
    else if (column == -1 && row <=15)
    {
        if(pixeldisplay[row][column+2] == MATRIX_G1 | pixeldisplay[row+1][column+2] == MATRIX_G1|pixeldisplay[row][column+1] == MATRIX_G1 | pixeldisplay[row+1][column+1] == MATRIX_G1)
                               return 1;
                     else
                        return 0;

    }
    else if (column == -1 && row > 15)
    {
        if(pixeldisplay[row][column+2] == MATRIX_G2 | pixeldisplay[row+1][column+2] == MATRIX_G2|pixeldisplay[row][column+1] == MATRIX_G2 | pixeldisplay[row+1][column+1] == MATRIX_G2)
                               return 1;
                     else
                        return 0;

    }
    else if (column == 31 && row <=15)
    {
        if(pixeldisplay[row][column] == MATRIX_G1 | pixeldisplay[row+1][column] == MATRIX_G1)
                               return 1;
                     else
                        return 0;

    }
    else if (column == 31 && row > 15)
    {
        if(pixeldisplay[row][column] == MATRIX_G2 | pixeldisplay[row+1][column] == MATRIX_G2)
                               return 1;
                     else
                        return 0;

    }
   else if((row<0) |(row>30) | (column>31)|column<-2){
                  return 0;
              }
   else if(row <=15)
    {
       if(pixeldisplay[row][column+2] == MATRIX_G2 | pixeldisplay[row+1][column+2] == MATRIX_G2|pixeldisplay[row][column+1] == MATRIX_G2 | pixeldisplay[row+1][column+1] == MATRIX_G2| pixeldisplay[row][column] == MATRIX_G2 | pixeldisplay[row+1][column] == MATRIX_G2)
            return 1;
        else
            return 0;
    }

    else
    {
        if(pixeldisplay[row][column+2] == MATRIX_G2 | pixeldisplay[row+1][column+2] == MATRIX_G2|pixeldisplay[row][column+1] == MATRIX_G2 | pixeldisplay[row+1][column+1] == MATRIX_G2| pixeldisplay[row][column] == MATRIX_G2 | pixeldisplay[row+1][column] == MATRIX_G2)
                   return 1;
               else
                   return 0;

    }
}

void TIM3_IRQHandler()
{
    TIM3->SR &= ~TIM_SR_UIF;

    if (!(GPIOB->IDR & (1<<1)))
            {

                       if(button_up==0)
                               {   move_up();
                                button_up =50;

            }
                       button_up++;
      }
    else
    {
        button_up=0;
    }

    if (!(GPIOB->IDR & (1<<0)))
            {

                if(button_left==0)
                        {   move_left();
                         button_left =50;
                        }

                 //move_left();
                button_left++;
            }
    else
        {
            button_left=0;
        }

    if (!(GPIOB->IDR & (1<<2)))
          {

        if(button_right==0)
        {move_right();
          button_right =50;
         }
        button_right++;

       }

    else
         {
             button_right=0;
         }

}
void gameover()
{
    for(int i=0; i < 33; i++) {
           for(int j=0; j < 32; j++) {
               if((i == 1)) {
                   pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_G1);
               }
               else if((i == 0) | (i == 33)){
                   if(i == 0) {

                           pixeldisplay[i][j] = MATRIX_R1;
                   } else {
                       pixeldisplay[i][j] = MATRIX_R2;
                   }
               }
               else if(i == 15) {
                   pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_B1);
               }
               else if((i == 16) | (i== 30) | (i== 31)){
                   pixeldisplay[i][j] = (MATRIX_R2 | MATRIX_B2);
               }
               else {
                   pixeldisplay[i][j] = 0;
               }
               if (i!=32 && game_over[i*32+j] == 1)
              {
                  if(i>15)
                      pixeldisplay[i][j] = MATRIX_R2;
                  else
                      pixeldisplay[i][j] = MATRIX_R1;
              }

           }
       }
}

