#include "stm32f0xx.h"
#include "stm32f0_discovery.h"
#include <stdbool.h>
#include <string.h>
#include "objects.h"
// YOU CANNOT USE THESE VALUES FOR GPIO_MODER as two bits represent one MODER port.
#define MATRIX_R1   0x1 //PC0
#define MATRIX_G1   0x2 //PC1
#define MATRIX_B1   0x4 //PC2
#define MATRIX_R2   0x8 //PC3
#define MATRIX_G2   0x10   //PC4
#define MATRIX_B2   0x20   //PC5
#define MATRIX_A    0x40   //PC6
#define MATRIX_B    0x80   //PC7
#define MATRIX_C    0x400  //PC10
#define MATRIX_D    0x800  //PC11
#define MATRIX_CLK  0x2000 //PC13
#define MATRIX_LAT  0x4000 //PC14
#define MATRIX_OE   0x1000 //PC12
#define MATRIX_LEDS 0x3F   //PC0-PC5
#define MATRIX_ROWS 0xCC0  //PC6, 7, 10, 11



bool  game_over[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,1,1,0,1,1,1,1,0,1,1,0,1,1,0,1,1,1,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,1,1,0,1,1,1,1,0,1,0,1,0,1,0,1,1,1,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,0,1,0,1,0,1,0,1,1,1,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,1,1,1,0,1,0,0,1,0,1,1,1,1,0,1,1,1,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,0,1,1,1,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,0,0,1,0,1,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,1,1,1,1,1,0,0,1,1,0,0,1,1,1,1,0,1,0,0,1,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

int button_up =50;
int button_right=50;
int button_left =50;

uint16_t pixeldisplay[33][32];
int pos_frog[2];
int count = 0;
int main(void)
{
    setup_GPIO();
    setup_array();
    pos_frog[0] = 30;
    pos_frog[1] =15;
    draw_frog(30,15);
    setup_gpio_buttons();
    setup_timer3();
    setup_timer6();
    //enable_exti1_0();
    //enable_exti2();
    //gameover();
    while(1)
    {

        setupDisplay();


    }
}
void moveV(vehicle v, int* position[2], uint16_t color, int direction, int type) {
    int size = 3;
    if(type == 1) {
        size = 3;
    } else {
        size = 2;
    }
    drawVehicle_car(v.position, color);
    int temp[2];
    temp[0] = v.position[0];
    temp[1] = v.position[1] - size;
    drawVehicle_car(temp, 0);
}
vehicle new;
void setup_timer6() {
    RCC -> APB1ENR |= RCC_APB1ENR_TIM6EN;
    TIM6 -> CR1 &= ~TIM_CR1_CEN;
    TIM6 -> ARR = 1000 - 1;
    TIM6 -> PSC = 10000- 1;
    TIM6 -> DIER |= TIM_DIER_UIE;
    NVIC -> ISER[0] = 1 << TIM6_DAC_IRQn;
    TIM6 -> CR1 |= TIM_CR1_CEN;
    count = 0;
}
void TIM6_DAC_IRQHandler() {
new.vtype=1;
TIM6 -> SR &= ~TIM_SR_UIF;
if(count < 33) {
        new.position[0] = 27;
        new.position[1] =-1 + count;
        moveV(new, new.position, MATRIX_B2, 1, 0);
        count++;
    }
else {
        count = 0;
        drawVehicle_car(new.position, 0);
    }

}

void drawVehicle_car(int position[2], uint16_t color){
                //row        column
    draw_pixel(position[0], position[1], color);
    draw_pixel(position[0] + 1, position[1], color);
    draw_pixel(position[0], position[1] + 1, color);
//    draw_pixel(position[0] + 1, position[1] + 2, color);
//    draw_pixel(position[0], position[1] + 2, color);
    draw_pixel(position[0] + 1, position[1] + 1, color);
}
void setup_GPIO() {
    RCC->AHBENR |= RCC_AHBENR_GPIOCEN;
    GPIOC->MODER &= ~0x3FF0FFFF; // We are using all PC pins except for 8,9,15
    GPIOC->MODER |= (0x15505555);
    GPIOC->PUPDR = (GPIOC->PUPDR & 0xC00F0000) | 0x15505555;
    GPIOC -> BSRR |= (0x7CFF<<16);
}

void setup_array() {
    for(int i=0; i < 33; i++) {
        for(int j=0; j < 32; j++) {
            if((i == 1)) {
                pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_G1);
            }
            else if((i == 0) | (i == 33)){
                if(i == 0) {

                        pixeldisplay[i][j] = MATRIX_R1;
                } else {
                    pixeldisplay[i][j] = MATRIX_R2;
                }
            }
            else if(i == 15) {
                pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_B1);
            }
            else if((i == 16) | (i== 30) | (i== 31)){
                pixeldisplay[i][j] = (MATRIX_R2 | MATRIX_B2);
            }
            else {
                pixeldisplay[i][j] = 0;
            }
        }
    }

}

void setupDisplay() {
    int row = 0;
    GPIOC -> BRR |= (MATRIX_CLK|MATRIX_LAT|MATRIX_OE);
    for(int i = 0; i < 33; i++) {
        for(int j = 0; j < 32; j++) {
          GPIOC ->BRR  |= MATRIX_LEDS;
          GPIOC->BSRR |= pixeldisplay[i][j];
          toggleClock();
          toggleClock();
        }
        if(i >= 16) {
            row = i - 16;
        } else {
            row = i;
        }
        GPIOC-> BSRR |= MATRIX_OE;
        GPIOC-> BSRR = (MATRIX_ROWS<<16);
        GPIOC-> BSRR |= (((row & 0x1) << 6)|(((row >> 1) & 0x1) << 7)|(((row >> 2) & 0x1) << 10)|(((row >> 3) & 0x1) << 11));
        GPIOC-> BSRR |= MATRIX_LAT;
        GPIOC-> BRR |= MATRIX_LAT;
        GPIOC-> BRR |= MATRIX_OE;
        GPIOC ->BRR  |= MATRIX_LEDS;
    }
}

void toggleClock() {
    if((GPIOC->ODR & MATRIX_CLK)>>13) {
        GPIOC->BSRR |= (MATRIX_CLK<<16);
    } else {
        GPIOC->BSRR |= MATRIX_CLK;
    }
    return;
}

void draw_pixel(int row, int column, uint16_t color) {
    if((row<0) | (column<0) | (row>32) | (column>31)){
        return;
    }
    pixeldisplay[row][column] = color;
}

void setup_gpio_buttons()
{
    //PB0, PB1, PB2 configured as input
    RCC -> AHBENR |= RCC_AHBENR_GPIOBEN;
    GPIOB -> MODER &= ~(GPIO_MODER_MODER0); //PB0 -> Left
    GPIOB -> MODER &= ~(GPIO_MODER_MODER1); //PB1 -> Up
    GPIOB -> MODER &= ~(GPIO_MODER_MODER2); //PB5 -> Right
    GPIOB->PUPDR &= ~(GPIO_PUPDR_PUPDR0|GPIO_PUPDR_PUPDR0|GPIO_PUPDR_PUPDR0);
    GPIOB->PUPDR |= (GPIO_PUPDR_PUPDR0_0|GPIO_PUPDR_PUPDR1_0|GPIO_PUPDR_PUPDR2_0);

}
void move_up()
{
    if(check_collision_frog(pos_frog[0]-1,pos_frog[1]))
         {
         TIM6 -> CR1 &= ~TIM_CR1_CEN;
         gameover();
         pos_frog[0] = 30;
         pos_frog[1] =15;
         draw_frog(30,15);
         return;
         }
    draw_frog(pos_frog[0]-1,pos_frog[1]);

}

void move_left()
{
    if(check_collision_frog(pos_frog[0],pos_frog[1]-1))
       {
       TIM6 -> CR1 &= ~TIM_CR1_CEN;
       gameover();
       pos_frog[0] = 30;
       pos_frog[1] =15;
       draw_frog(30,15);
       return;
       }
    draw_frog(pos_frog[0],pos_frog[1]-1);
}

void move_right()
{
    if(check_collision_frog(pos_frog[0], pos_frog[1]+1))
    {
    TIM6 -> CR1 &= ~TIM_CR1_CEN;
    gameover();
    pos_frog[0] = 30;
    pos_frog[1] =15;
    draw_frog(30,15);
    return;
    }
    draw_frog(pos_frog[0], pos_frog[1]+1);

}

void draw_frog(int row, int column)
{
    if((row<0) | (column<0) | (row>30) | (column>30)){
              return;
          }

    draw_pixel(pos_frog[0],pos_frog[1],0);
    draw_pixel(pos_frog[0]+1,pos_frog[1],0);
    draw_pixel(pos_frog[0]+1,pos_frog[1]+1,0);
    draw_pixel(pos_frog[0],pos_frog[1]+1,0);

    if(pos_frog[0] == 15)
    {   draw_pixel(pos_frog[0],pos_frog[1],MATRIX_B1|MATRIX_R1);
        draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_B1|MATRIX_R1);
    }
    else if(pos_frog[0]== 16 || pos_frog[0]== 30 || pos_frog[0]== 31)
    {
        draw_pixel(pos_frog[0],pos_frog[1],MATRIX_B2|MATRIX_R2);
        draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_B2|MATRIX_R2);

    }
    else if(pos_frog[0]==0)
   {
           draw_pixel(pos_frog[0],pos_frog[1],MATRIX_R1);
           draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_R1);

   }

    else if(pos_frog[0]==1)
      {
                draw_pixel(pos_frog[0],pos_frog[1],MATRIX_R1|MATRIX_G1);
                draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_R1|MATRIX_G1);

       }
     if (pos_frog[0]+ 1 == 15 )
    {
    draw_pixel(pos_frog[0]+1,pos_frog[1],MATRIX_B1|MATRIX_R1);
    draw_pixel(pos_frog[0]+1,pos_frog[1]+1,MATRIX_B1|MATRIX_R1);
    }

    else if(pos_frog[0]+ 1 == 16 || pos_frog[0]+ 1 == 30 || pos_frog[0]+ 1 == 31)
    {
        draw_pixel(pos_frog[0]+1,pos_frog[1],MATRIX_B2|MATRIX_R2);
        draw_pixel(pos_frog[0]+1,pos_frog[1]+1,MATRIX_B2|MATRIX_R2);

    }


    else if(pos_frog[0]+1==1)
    {
           draw_pixel(pos_frog[0]+1,pos_frog[1],MATRIX_R1|MATRIX_G1);
           draw_pixel(pos_frog[0]+1,pos_frog[1]+1,MATRIX_R1|MATRIX_G1);

     }

    if(row < 15)
    {
       draw_pixel(row,column,MATRIX_G1);
       draw_pixel(row+1,column,MATRIX_G1);
       draw_pixel(row,column+1,MATRIX_G1);
       draw_pixel(row+1,column+1,MATRIX_G1);
    }
    else if(row == 15)
    {
        draw_pixel(row,column+1,MATRIX_G1);
        draw_pixel(row,column,MATRIX_G1);
        draw_pixel(row+1,column,MATRIX_G2);
        draw_pixel(row+1,column+1,MATRIX_G2);
    }

    else
    {
        draw_pixel(row,column,MATRIX_G2);
        draw_pixel(row+1,column,MATRIX_G2);
        draw_pixel(row,column+1,MATRIX_G2);
        draw_pixel(row+1,column+1,MATRIX_G2);
    }
    pos_frog[0] = row;
    pos_frog[1] = column;
}

void setup_timer3() {
    /* Student code goes here */
     RCC ->APB1ENR |= RCC_APB1ENR_TIM3EN;
     TIM3->ARR = 200 - 1;
     TIM3->PSC = 1200 - 1;
     TIM3->DIER |= TIM_DIER_UIE;
     TIM3 ->CR1 |= TIM_CR1_CEN;
     NVIC->ISER[0] = 1<<TIM3_IRQn;

}

int check_collision_frog(int row,int  column)
{
    if((row<0) | (column<0) | (row>30) | (column>30)){
                  return 0;
              }
    if(row <=15)
    {
        if(pixeldisplay[row][column] == MATRIX_B1|pixeldisplay[row+1][column] == MATRIX_B1| pixeldisplay[row][column+1] == MATRIX_B1|pixeldisplay[row+1][column+1] == MATRIX_B1)
            return 1;
        else if(pixeldisplay[row][column] == (MATRIX_B1|MATRIX_G1)|pixeldisplay[row+1][column] == (MATRIX_B1|MATRIX_G1)|pixeldisplay[row][column+1] == (MATRIX_B1|MATRIX_G1)|pixeldisplay[row+1][column+1] == (MATRIX_B1|MATRIX_G1))
            return 1;
        else
            return 0;
    }

    else
    {
        if(pixeldisplay[row][column] == MATRIX_B2|pixeldisplay[row+1][column] == MATRIX_B2| pixeldisplay[row][column+1] == MATRIX_B2|pixeldisplay[row+1][column+1] == MATRIX_B2)
                   return 1;
               else if(pixeldisplay[row][column] == (MATRIX_B2|MATRIX_G2)|pixeldisplay[row+1][column] == (MATRIX_B2|MATRIX_G2)|pixeldisplay[row][column+1] == (MATRIX_B2|MATRIX_G2)|pixeldisplay[row+1][column+1] == (MATRIX_B2|MATRIX_G2))
                   return 1;
               else
                   return 0;

    }
}

int check_collision_car(int row,int  column)
{
    if((row<0) | (column<0) | (row>30) | (column>30)){
                  return 0;
              }
    if(row <=15)
    {
        if(pixeldisplay[row][column] == MATRIX_G1|pixeldisplay[row+1][column] == MATRIX_G1| pixeldisplay[row][column+1] == MATRIX_B1|pixeldisplay[row+1][column+1] == MATRIX_B1)
            return 1;
        else if(pixeldisplay[row][column] == (MATRIX_B1|MATRIX_G1)|pixeldisplay[row+1][column] == (MATRIX_B1|MATRIX_G1)|pixeldisplay[row][column+1] == (MATRIX_B1|MATRIX_G1)|pixeldisplay[row+1][column+1] == (MATRIX_B1|MATRIX_G1))
            return 1;
        else
            return 0;
    }

    else
    {
        if(pixeldisplay[row][column] == MATRIX_B2|pixeldisplay[row+1][column] == MATRIX_B2| pixeldisplay[row][column+1] == MATRIX_B2|pixeldisplay[row+1][column+1] == MATRIX_B2)
                   return 1;
        else if(pixeldisplay[row][column] == (MATRIX_B2|MATRIX_G2)|pixeldisplay[row+1][column] == (MATRIX_B2|MATRIX_G2)|pixeldisplay[row][column+1] == (MATRIX_B2|MATRIX_G2)|pixeldisplay[row+1][column+1] == (MATRIX_B2|MATRIX_G2))
                   return 1;
               else
                   return 0;

    }
}

void TIM3_IRQHandler()
{
    TIM3->SR &= ~TIM_SR_UIF;

    if (!(GPIOB->IDR & (1<<1)))
            {

                       if(button_up==0)
                               {   move_up();
                                button_up =50;

            }
                       button_up++;
      }
    else
    {
        button_up=0;
    }

    if (!(GPIOB->IDR & (1<<0)))
            {

                if(button_left==0)
                        {   move_left();
                         button_left =50;
                        }

                 //move_left();
                button_left++;
            }
    else
        {
            button_left=0;
        }

    if (!(GPIOB->IDR & (1<<2)))
          {

        if(button_right==0)
        {move_right();
          button_right =50;
         }
        button_right++;

       }

    else
         {
             button_right=0;
         }

}
void gameover()
{
    for(int i=0; i < 33; i++) {
           for(int j=0; j < 32; j++) {
               if((i == 1)) {
                   pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_G1);
               }
               else if((i == 0) | (i == 33)){
                   if(i == 0) {

                           pixeldisplay[i][j] = MATRIX_R1;
                   } else {
                       pixeldisplay[i][j] = MATRIX_R2;
                   }
               }
               else if(i == 15) {
                   pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_B1);
               }
               else if((i == 16) | (i== 30) | (i== 31)){
                   pixeldisplay[i][j] = (MATRIX_R2 | MATRIX_B2);
               }
               else {
                   pixeldisplay[i][j] = 0;
               }
               if (i!=32 && game_over[i*32+j] == 1)
              {
                  if(i>15)
                      pixeldisplay[i][j] = MATRIX_R2;
                  else
                      pixeldisplay[i][j] = MATRIX_R1;
              }

           }
       }
}

