typedef struct vehicle {
    int position[2];  // x,y position
    int vtype;  // 0 for car, 1 for truck
    int delay;  // how much lag time on rows
    int direction;  // 1 for right, -1 for left
    uint16_t color;
    int count;
} vehicle;

vehicle vlist[32];

void setup_array();
void setupDisplay();
void setup_GPIO();
void toggleClock();
void setup_timer6();
void TIM6_DAC_IRQHandler();
void draw_pixel(int row, int column, uint16_t color);
void draw_frog();
void patch();
void moveV(vehicle * v);
void drawVehicle_car(int position[2], uint16_t color);
vehicle createStruct(int x, int y, int vtype, int delay, int direction, uint16_t color);
void generateVehicles(int n);
void manageCount(vehicle * v);
