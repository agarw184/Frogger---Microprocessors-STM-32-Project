#include "stm32f0xx.h"
#include "stm32f0_discovery.h"
#include <stdbool.h>
#include <string.h>
#include "objects.h"

// YOU CANNOT USE THESE VALUES FOR GPIO_MODER as two bits represent one MODER port.
#define MATRIX_R1   0x1 //PC0
#define MATRIX_G1   0x2 //PC1
#define MATRIX_B1   0x4 //PC2
#define MATRIX_R2   0x8 //PC3
#define MATRIX_G2   0x10   //PC4
#define MATRIX_B2   0x20   //PC5
#define MATRIX_A    0x40   //PC6
#define MATRIX_B    0x80   //PC7
#define MATRIX_C    0x400  //PC10
#define MATRIX_D    0x800  //PC11
#define MATRIX_CLK  0x2000 //PC13
#define MATRIX_LAT  0x4000 //PC14
#define MATRIX_OE   0x1000 //PC12
#define MATRIX_LEDS 0x3F   //PC0-PC5
#define MATRIX_ROWS 0xCC0  //PC6, 7, 10, 11
#define WIDTH 32
#define NUM_ROWS 16

uint16_t pixeldisplay[33][32];
// pixel[i][j]  The ith row and jth column

//Variables
int count = 0;
int setup=0;


int main(void)
{
    setup_GPIO();
    setup_array();
    setup_timer6();
    generateVehicles(32);
    //patch();
    while(1)
    {
        draw_frog();
        setupDisplay();

    }
}

void patch() {
    draw_pixel(1, 31,MATRIX_G1|MATRIX_R1);
    draw_pixel(1, 30,MATRIX_G1|MATRIX_R1);
    draw_pixel(1, 29,MATRIX_G1|MATRIX_R1);
}


void setup_timer6() {
    RCC -> APB1ENR |= RCC_APB1ENR_TIM6EN;
    TIM6 -> CR1 &= ~TIM_CR1_CEN;
    TIM6 -> ARR = 1000 - 1;
    TIM6 -> PSC = 10000 - 1;
    TIM6 -> DIER |= TIM_DIER_UIE;
    NVIC -> ISER[0] = 1 << TIM6_DAC_IRQn;
    TIM6 -> CR1 |= TIM_CR1_CEN;
}


void draw_frog() {
    draw_pixel(31,15,MATRIX_G2);
    draw_pixel(31,16,MATRIX_G2);
    draw_pixel(30,15,MATRIX_G2);
    draw_pixel(30,16,MATRIX_G2);
}


void TIM6_DAC_IRQHandler() {
    TIM6 -> SR &= ~TIM_SR_UIF;
    for(int i = 0; i < 32; i++) {
        if(i == 0) {
            manageCount(&vlist[i]);
        } else if(vlist[i-1].count >= 9) {
            manageCount(&vlist[i]);
        }
    }
}

void manageCount(vehicle * v) {
    if(v->count < 33) {
        v->position[1] = -1 + v->count;
        moveV(v);
        v->count++;
    } else {
        drawVehicle_car(v->position, 0);
    }
}

void generateVehicles(int n) {
    for(int i = 0; i < n; i++) {
        vlist[i] = createStruct(2, -1, 1, 0, 1, (MATRIX_B2 | MATRIX_G2));
    }
}

vehicle createStruct(int x, int y, int vtype, int delay, int direction, uint16_t color) {
    vehicle fresh;
    fresh.position[0] = x;
    fresh.position[1] = y;
    fresh.vtype = vtype;
    fresh.delay = delay;
    fresh.direction = direction;
    fresh.color = color;
    fresh.count = -1;
    return fresh;
}

void moveV(vehicle * v) {
    int size;
    if(v->vtype == 1) {
        size = 3;
    } else {
        size = 2;
    }
    drawVehicle_car(v->position, v->color);
    int temp[2];
    temp[0] = v->position[0];
    temp[1] = v->position[1] - size;
    drawVehicle_car(temp, 0);
}

void drawVehicle_car(int position[2], uint16_t color){
                //row        column
    draw_pixel(position[0], position[1], color);
    draw_pixel(position[0] + 1, position[1], color);
    draw_pixel(position[0], position[1] + 1, color);
    draw_pixel(position[0] + 1, position[1] + 2, color);
    draw_pixel(position[0], position[1] + 2, color);
    draw_pixel(position[0] + 1, position[1] + 1, color);
}



void draw_pixel(int row, int column, uint16_t color) {
    if((row<0) | (column<0) | (row>32) | (column>31)){
        return;
    }
    pixeldisplay[row][column] = color;
}

void toggleClock() {
    if((GPIOC->ODR & MATRIX_CLK)>>13) {
        GPIOC->BSRR |= (MATRIX_CLK<<16);
    } else {
        GPIOC->BSRR |= MATRIX_CLK;
    }
    return;
}


void setup_GPIO() {
    RCC->AHBENR |= RCC_AHBENR_GPIOCEN;
    GPIOC->MODER &= ~0x3FF0FFFF; // We are using all PC pins except for 8,9,15
    GPIOC->MODER |= (0x15505555);
    GPIOC->PUPDR = (GPIOC->PUPDR & 0xC00F0000) | 0x15505555;
    GPIOC -> BSRR |= (0x7CFF<<16);
}


void setup_array() {
    for(int i=0; i < 33; i++) {
        for(int j=0; j < 32; j++) {
            if((i == 1)) {
                pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_G1);
            }
            else if((i == 0) | (i == 33)){
                if(i == 0) {
                    pixeldisplay[i][j] = MATRIX_R1;
                } else {
                    pixeldisplay[i][j] = MATRIX_R2;
                }
            }
            else if(i == 15) {
                pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_B1);
            }
            else if((i == 16) | (i== 30) | (i== 31)){
                pixeldisplay[i][j] = (MATRIX_R2 | MATRIX_B2);
            }
            else {
                pixeldisplay[i][j] = 0;
            }
        }
    }
}


void setupDisplay() {
    int row = 0;
    GPIOC -> BRR |= (MATRIX_CLK|MATRIX_LAT|MATRIX_OE);
    for(int i = 0; i < 33; i++) {
        for(int j = 0; j < 32; j++) {
          GPIOC ->BRR  |= MATRIX_LEDS;
          GPIOC->BSRR |= pixeldisplay[i][j];
          toggleClock();
          toggleClock();
        }
        if(i >= 16) {
            row = i - 16;
        } else {
            row = i;
        }
        GPIOC-> BSRR |= MATRIX_OE;
        GPIOC-> BSRR = (MATRIX_ROWS<<16);
        GPIOC-> BSRR |= (((row & 0x1) << 6)|(((row >> 1) & 0x1) << 7)|(((row >> 2) & 0x1) << 10)|(((row >> 3) & 0x1) << 11));
        GPIOC-> BSRR |= MATRIX_LAT;
        GPIOC-> BRR |= MATRIX_LAT;
        GPIOC-> BRR |= MATRIX_OE;
        GPIOC ->BRR  |= MATRIX_LEDS;
    }
}
