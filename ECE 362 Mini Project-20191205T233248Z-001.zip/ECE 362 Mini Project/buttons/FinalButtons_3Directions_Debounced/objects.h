typedef struct vehicle {
    int position[2];  // x,y position
    int vtype;  // 0 for car, 1 for truck
    int delay;  // how much lag time on rows
    int direction;  // 1 for right, -1 for left
    uint16_t color;
    int count;
} vehicle;

vehicle vlist[32];

void setup_GPIO();
void setup_array();
void setupDisplay();
void toggleClock();
void draw_pixel(int row, int column, uint16_t color);
void setup_gpio_buttons();
void move_up();
void move_left();
void draw_frog(int row, int column);
void restoreroads();
void enable_exti1_0();
void EXTI0_1_IRQHandler();
void enable_exti2();
void EXTI2_3_IRQHandler();
void move_right();
void setup_timer3();
