#include "stm32f0xx.h"
#include "stm32f0_discovery.h"
#include <stdbool.h>
#include <string.h>
#include "objects.h"


// YOU CANNOT USE THESE VALUES FOR GPIO_MODER as two bits represent one MODER port.
#define MATRIX_R1   0x1 //PC0
#define MATRIX_G1   0x2 //PC1
#define MATRIX_B1   0x4 //PC2
#define MATRIX_R2   0x8 //PC3
#define MATRIX_G2   0x10   //PC4
#define MATRIX_B2   0x20   //PC5
#define MATRIX_A    0x40   //PC6
#define MATRIX_B    0x80   //PC7
#define MATRIX_C    0x400  //PC10
#define MATRIX_D    0x800  //PC11
#define MATRIX_CLK  0x2000 //PC13
#define MATRIX_LAT  0x4000 //PC14
#define MATRIX_OE   0x1000 //PC12
#define MATRIX_LEDS 0x3F   //PC0-PC5
#define MATRIX_ROWS 0xCC0  //PC6, 7, 10, 11

int button_up =0;
int button_right=0;
int button_left =0;

uint16_t pixeldisplay[33][32];
int pos_frog[2];
int main(void)
{
    setup_GPIO();
    setup_array();
    pos_frog[0] = 30;
    pos_frog[1] =15;
    draw_frog(30,15);
    setup_gpio_buttons();
    setup_timer3();
    //enable_exti1_0();
    //enable_exti2();
    while(1)
    {

        setupDisplay();


    }
}

void setup_GPIO() {
    RCC->AHBENR |= RCC_AHBENR_GPIOCEN;
    GPIOC->MODER &= ~0x3FF0FFFF; // We are using all PC pins except for 8,9,15
    GPIOC->MODER |= (0x15505555);
    GPIOC->PUPDR = (GPIOC->PUPDR & 0xC00F0000) | 0x15505555;
    GPIOC -> BSRR |= (0x7CFF<<16);
}

void setup_array() {
    for(int i=0; i < 33; i++) {
        for(int j=0; j < 32; j++) {
            if((i == 1)) {
                pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_G1);
            }
            else if((i == 0) | (i == 33)){
                if(i == 0) {

                        pixeldisplay[i][j] = MATRIX_R1;
                } else {
                    pixeldisplay[i][j] = MATRIX_R2;
                }
            }
            else if(i == 15) {
                pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_B1);
            }
            else if((i == 16) | (i== 30) | (i== 31)){
                pixeldisplay[i][j] = (MATRIX_R2 | MATRIX_B2);
            }
            else {
                pixeldisplay[i][j] = 0;
            }
        }
    }

}

void setupDisplay() {
    int row = 0;
    GPIOC -> BRR |= (MATRIX_CLK|MATRIX_LAT|MATRIX_OE);
    for(int i = 0; i < 33; i++) {
        for(int j = 0; j < 32; j++) {
          GPIOC ->BRR  |= MATRIX_LEDS;
          GPIOC->BSRR |= pixeldisplay[i][j];
          toggleClock();
          toggleClock();
        }
        if(i >= 16) {
            row = i - 16;
        } else {
            row = i;
        }
        GPIOC-> BSRR |= MATRIX_OE;
        GPIOC-> BSRR = (MATRIX_ROWS<<16);
        GPIOC-> BSRR |= (((row & 0x1) << 6)|(((row >> 1) & 0x1) << 7)|(((row >> 2) & 0x1) << 10)|(((row >> 3) & 0x1) << 11));
        GPIOC-> BSRR |= MATRIX_LAT;
        GPIOC-> BRR |= MATRIX_LAT;
        GPIOC-> BRR |= MATRIX_OE;
        GPIOC ->BRR  |= MATRIX_LEDS;
    }
}

void toggleClock() {
    if((GPIOC->ODR & MATRIX_CLK)>>13) {
        GPIOC->BSRR |= (MATRIX_CLK<<16);
    } else {
        GPIOC->BSRR |= MATRIX_CLK;
    }
    return;
}

void draw_pixel(int row, int column, uint16_t color) {
    if((row<0) | (column<0) | (row>32) | (column>31)){
        return;
    }
    pixeldisplay[row][column] = color;
}

void setup_gpio_buttons()
{
    //PB0, PB1, PB2 configured as input
    RCC -> AHBENR |= RCC_AHBENR_GPIOBEN;
    GPIOB -> MODER &= ~(GPIO_MODER_MODER0); //PB0 -> Left
    GPIOB -> MODER &= ~(GPIO_MODER_MODER1); //PB1 -> Up
    GPIOB -> MODER &= ~(GPIO_MODER_MODER2); //PB5 -> Right
    GPIOB->PUPDR &= ~(GPIO_PUPDR_PUPDR0|GPIO_PUPDR_PUPDR0|GPIO_PUPDR_PUPDR0);
    GPIOB->PUPDR |= (GPIO_PUPDR_PUPDR0_0|GPIO_PUPDR_PUPDR1_0|GPIO_PUPDR_PUPDR2_0);

}
void move_up()
{
    draw_frog(pos_frog[0]-1,pos_frog[1]);

}

void move_left()
{
    draw_frog(pos_frog[0],pos_frog[1]-1);
}

void draw_frog(int row, int column)
{
    if((row<0) | (column<0) | (row>30) | (column>30)){
              return;
          }

    draw_pixel(pos_frog[0],pos_frog[1],0);
    draw_pixel(pos_frog[0]+1,pos_frog[1],0);
    draw_pixel(pos_frog[0]+1,pos_frog[1]+1,0);
    draw_pixel(pos_frog[0],pos_frog[1]+1,0);

    if(pos_frog[0] == 15)
    {   draw_pixel(pos_frog[0],pos_frog[1],MATRIX_B1|MATRIX_R1);
        draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_B1|MATRIX_R1);
    }
    else if(pos_frog[0]== 16 || pos_frog[0]== 30 || pos_frog[0]== 31)
    {
        draw_pixel(pos_frog[0],pos_frog[1],MATRIX_B2|MATRIX_R2);
        draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_B2|MATRIX_R2);

    }
    else if(pos_frog[0]==0)
   {
           draw_pixel(pos_frog[0],pos_frog[1],MATRIX_R1);
           draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_R1);

   }

    else if(pos_frog[0]==1)
      {
                draw_pixel(pos_frog[0],pos_frog[1],MATRIX_R1|MATRIX_G1);
                draw_pixel(pos_frog[0],pos_frog[1]+1,MATRIX_R1|MATRIX_G1);

       }
     if (pos_frog[0]+ 1 == 15 )
    {
    draw_pixel(pos_frog[0]+1,pos_frog[1],MATRIX_B1|MATRIX_R1);
    draw_pixel(pos_frog[0]+1,pos_frog[1]+1,MATRIX_B1|MATRIX_R1);
    }

    else if(pos_frog[0]+ 1 == 16 || pos_frog[0]+ 1 == 30 || pos_frog[0]+ 1 == 31)
    {
        draw_pixel(pos_frog[0]+1,pos_frog[1],MATRIX_B2|MATRIX_R2);
        draw_pixel(pos_frog[0]+1,pos_frog[1]+1,MATRIX_B2|MATRIX_R2);

    }


    else if(pos_frog[0]+1==1)
    {
           draw_pixel(pos_frog[0]+1,pos_frog[1],MATRIX_R1|MATRIX_G1);
           draw_pixel(pos_frog[0]+1,pos_frog[1]+1,MATRIX_R1|MATRIX_G1);

     }

    if(row < 15)
    {
       draw_pixel(row,column,MATRIX_G1);
       draw_pixel(row+1,column,MATRIX_G1);
       draw_pixel(row,column+1,MATRIX_G1);
       draw_pixel(row+1,column+1,MATRIX_G1);
    }
    else if(row == 15)
    {
        draw_pixel(row,column+1,MATRIX_G1);
        draw_pixel(row,column,MATRIX_G1);
        draw_pixel(row+1,column,MATRIX_G2);
        draw_pixel(row+1,column+1,MATRIX_G2);
    }

    else
    {
        draw_pixel(row,column,MATRIX_G2);
        draw_pixel(row+1,column,MATRIX_G2);
        draw_pixel(row,column+1,MATRIX_G2);
        draw_pixel(row+1,column+1,MATRIX_G2);
    }
    pos_frog[0] = row;
    pos_frog[1] = column;
}

void setup_timer3() {
    /* Student code goes here */
     RCC ->APB1ENR |= RCC_APB1ENR_TIM3EN;
     TIM3->ARR = 200 - 1;
     TIM3->PSC = 1200 - 1;
     TIM3->DIER |= TIM_DIER_UIE;
     TIM3 ->CR1 |= TIM_CR1_CEN;
     NVIC->ISER[0] = 1<<TIM3_IRQn;

}


void TIM3_IRQHandler()
{
    TIM3->SR &= ~TIM_SR_UIF;

    if (!(GPIOB->IDR & (1<<1)))
            {
                button_up++;
                       if(button_up==40)
                               {   move_up();
                                button_up =0;
                               }
      }

    if (!(GPIOB->IDR & (1<<0)))
            {
                button_left++;
                if(button_left==40)
                        {   move_left();
                         button_left =0;
                        }

                 //GPIOB->ODR |= GPIO_BRR_BR_0;
                 //move_left();
            }
    if (!(GPIOB->IDR & (1<<2)))
          {
            button_right++;
        if(button_right==40)
         {move_right();
          button_right =0;
         }
        // GPIOB->ODR |= GPIO_BRR_BR_2;
       }
}

void move_right()
{

    draw_frog(pos_frog[0], pos_frog[1]+1);

}
