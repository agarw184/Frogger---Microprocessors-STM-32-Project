#include "stm32f0xx.h"
#include "stm32f0_discovery.h"
#include <stdbool.h>
#include <string.h>
#include "objects.h"

// YOU CANNOT USE THESE VALUES FOR GPIO_MODER as two bits represent one MODER port.
#define MATRIX_R1   0x1 //PC0
#define MATRIX_G1   0x2 //PC1
#define MATRIX_B1   0x4 //PC2
#define MATRIX_R2   0x8 //PC3
#define MATRIX_G2   0x10   //PC4
#define MATRIX_B2   0x20   //PC5
#define MATRIX_A    0x40   //PC6
#define MATRIX_B    0x80   //PC7
#define MATRIX_C    0x400  //PC10
#define MATRIX_D    0x800  //PC11
#define MATRIX_CLK  0x2000 //PC13
#define MATRIX_LAT  0x4000 //PC14
#define MATRIX_OE   0x1000 //PC12
#define MATRIX_LEDS 0x3F   //PC0-PC5
#define MATRIX_ROWS 0xCC0  //PC6, 7, 10, 11
#define WIDTH 32
#define NUM_ROWS 16

uint16_t pixeldisplay[33][32];
// pixel[i][j]  The ith row and jth column


void setup_array();
void setupDisplay();
void setup_GPIO();
int toggleClock();
void setup_timer6();
void TIM6_DAC_IRQHandler();
void draw_pixel(int row, int column, uint16_t color);
void draw_frog();
void moveVehicle(vehicle vehicleType, int x, int y, uint16_t color, int direction, int type);
void drawVehicle(int position[2], uint16_t color);

//Variables
int count = 0;
int setup=0;

int main(void)
{
    setup_GPIO();
    setup_array();
    setup_timer6();
    // create instances of cars and trucks
    // add delays so they have different rates
    while(1)
    {
    	draw_frog();
    	setupDisplay();
    }
}


void setup_timer6() {
	RCC ->APB1ENR |= RCC_APB1ENR_TIM6EN;
	TIM6 ->CR1 &= ~TIM_CR1_CEN;
	TIM6->ARR = 10000 - 1;
	TIM6->PSC = 1000 - 1;
	TIM6->DIER |= TIM_DIER_UIE;
	NVIC->ISER[0] = 1 << TIM6_DAC_IRQn;
	TIM6 ->CR1 |= TIM_CR1_CEN;
}


void draw_frog() {
    draw_pixel(31,15,MATRIX_G2);
    draw_pixel(31,16,MATRIX_G2);
    draw_pixel(30,15,MATRIX_G2);
    draw_pixel(30,16,MATRIX_G2);
}

void TIM6_DAC_IRQHandler() {
	TIM6 -> SR &= ~TIM_SR_UIF;
	if(count == 34) {
		count = 0;
	}
	vehicle new;
	moveVehicle(new, 2, 0, MATRIX_B2, 1, 0);
	vehicle other;
	moveVehicle(other, 3, 31, MATRIX_B1, -1, 0);
	vehicle better;
	moveVehicle(better, 7, 31, MATRIX_B2, -1, 0);
	vehicle bus;
	moveVehicle(bus, 8, 0, MATRIX_R1, 1, 1);
	count++;
}


void moveVehicle(vehicle vehicleType, int x, int y, uint16_t color, int direction, int type) {
	int size;
	if(type == 1) {
		size = 3;
	} else {
		size = 2;
	}
	if(direction == 1) {
		vehicleType.position[0] = x;
		vehicleType.position[1] = y + count;
		drawVehicle(vehicleType.position, color);
		int temp[2];
		temp[0] = x;
		temp[1] = y + count - size;
		drawVehicle(temp, 0);
	} else {
		vehicleType.position[0] = x;
		vehicleType.position[1] = y - count;
		drawVehicle(vehicleType.position, color);
		int temp[2];
		temp[0] = x;
		temp[1] = y - count + size;
		drawVehicle(temp, 0);
	}
}

void drawVehicle(int position[2], uint16_t color){
    draw_pixel(position[0], position[1], color);
    draw_pixel(position[0] + 1, position[1], color);
    draw_pixel(position[0], position[1] + 1, color);
    draw_pixel(position[0] + 1, position[1] + 1, color);
}

void draw_pixel(int row, int column, uint16_t color) {
      for (int i = 0; i < 33; i++)
      {
          for (int  j = 0; j < 32; j++)
          {
              if (i == row && j == column)
                  pixeldisplay[i][j] = color;
          }
      }

}

int toggleClock() {
    if((GPIOC->ODR & MATRIX_CLK)>>13) {
        GPIOC->BSRR |= (MATRIX_CLK<<16);
        return 0;
    }
    else {
		GPIOC->BSRR |= MATRIX_CLK;
		return 0;
    }
}


void setup_GPIO()
{
	RCC->AHBENR |= RCC_AHBENR_GPIOCEN;
	GPIOC->MODER &= ~0x3FF0FFFF; // We are using all PC pins except for 8,9,15
	GPIOC->MODER |= (0x15505555);
	GPIOC->PUPDR = (GPIOC->PUPDR & 0xC00F0000) | 0x15505555;
	GPIOC -> BSRR |= (0x7CFF<<16);
}


void setup_array()
{
	for(int i=0; i < 33; i++) {
		for(int j=0; j < 32; j++) {
			if((i == 1)) {
				pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_G1);
			}
			else if((i == 0) | (i == 33)){
				if(i == 0) {
					pixeldisplay[i][j] = MATRIX_R1;
				} else {
					pixeldisplay[i][j] = MATRIX_R2;
				}
			}
			else if(i == 15) {
				pixeldisplay[i][j] = (MATRIX_R1 | MATRIX_B1);
			}
			else if((i == 16) | (i== 30) | (i== 31)){
				pixeldisplay[i][j] = (MATRIX_R2 | MATRIX_B2);
			}
			else {
				pixeldisplay[i][j] = 0;
			}
		}
	}
}


void setupDisplay()
{
	int row = 0;
	GPIOC -> BRR |= (MATRIX_CLK|MATRIX_LAT|MATRIX_OE);
	for(int i = 0; i<33; i++) {
	  for(int j = 0; j < 32; j++) {
		  GPIOC ->BRR  |= MATRIX_LEDS;
		  GPIOC->BSRR |= pixeldisplay[i][j];
		  toggleClock();
		  toggleClock();

	  }
	 if(i >= 16) {
		 row = i - 16;
	 } else {
		 row = i;
	 }

		GPIOC-> BSRR |= MATRIX_OE;
		GPIOC-> BSRR = (MATRIX_ROWS<<16);
		GPIOC-> BSRR |= (((row & 0x1) << 6)|(((row >> 1) & 0x1) << 7)|(((row >> 2) & 0x1) << 10)|(((row >> 3) & 0x1) << 11));
		GPIOC-> BSRR |= MATRIX_LAT;
		GPIOC-> BRR |= MATRIX_LAT;

		GPIOC-> BRR |= MATRIX_OE;
		GPIOC ->BRR  |= MATRIX_LEDS;
	}

}

//void car_obstructions() {
//    for (int j =0; j < 28; j = j+9)
//    {
//    //Calls Top 32 rows
//        for (int i = 3; i < 15; i = i + 4)
//        {
//        drawTile(i,j,2,MATRIX_B1);
//        drawTile(i,j,2,MATRIX_B1);
//        drawTile(i,j,2,MATRIX_B1);
//        drawTile(i,j,2,MATRIX_B1);
//       // drawTile(i,j,1,MATRIX_B1);
//        }
//    //Calls Bottom 32 rows
//        for (int i = 19; i < 30; i = i + 4)
//        {
//        drawTile(i,j,2,MATRIX_B2);
//        drawTile(i,j,2,MATRIX_B2);
//        drawTile(i,j,2,MATRIX_B2);
//        drawTile(i,j,2,MATRIX_B2);
//        }
//    }
//}
//
//void bus_obstructions()
//{
//    for (int j = 4; j < 32; j=j+9)
//    {
//        for (int i = 2; i < 13; i = i + 4)
//        {
//            drawTile(i,j,3,MATRIX_R1);
//            drawTile(i,j,3,MATRIX_R1);
//            drawTile(i,j,3,MATRIX_R1);
//            drawTile(i,j,3,MATRIX_R1);
//        }
//        for (int i = 19; i < 30; i = i + 4)
//        {
//            drawTile(i,j,3,MATRIX_R2);
//            drawTile(i,j,3,MATRIX_R2);
//            drawTile(i,j,3,MATRIX_R2);
//            drawTile(i,j,3,MATRIX_R2);
//        }
//    }
//}
//
//void drawTile(uint8_t x, uint8_t y, uint8_t size, uint16_t color)
//{
//    for (uint8_t i = 0; i < size; i++)
//    {
//        for (uint8_t j = 0; j < size; j++)
//        {
//            draw_pixel(x + i, y + j, color);
//        }
//    }
//}


