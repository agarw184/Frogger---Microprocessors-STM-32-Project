typedef struct vehicle {
	int position[2];  // x,y position
	int vtype;  // 0 for car, 1 for truck
	int delay;  // how much lag time on rows
	int direction;  // 1 for right, -1 for left
} vehicle;

vehicle vlist[32];
