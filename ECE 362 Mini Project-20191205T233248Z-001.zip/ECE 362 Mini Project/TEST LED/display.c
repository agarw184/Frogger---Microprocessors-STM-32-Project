#include "stm32f0xx.h"
#include "stm32f0_discovery.h"
#include <string.h>
#include "display.h"


/**
 * Initialize the LED matrix on startup.
 */
void initMatrix() {
    initPorts(); //Setup initial GPIO output values
    row = 0; //Initialize the current row value to 0

    //Allocate memory for the image data (matrix buffer).
    //The "*3" stores 3 bytes to hold 4 "packed" planes.
    memset(matrixBuffer, 0, WIDTH * NUM_ROWS * 3);
}

/**
 * Reset all output values (turn off any output)
 */
void initPorts() {
    GPIOC->ODR &= ~MATRIX_CLK; //CLK low
    GPIOC->ODR &= ~MATRIX_LAT; //LAT low
    GPIOC->ODR |= MATRIX_OE;   //OE high (disable output)
    GPIOC->ODR &= ~MATRIX_ROWS; //Set row output to 0
    GPIOC->ODR &= ~MATRIX_LEDS; //Turn off all LEDs
}

/**
 * Redraws the display. Called by the TIM3 interrupt handler.
 */
void refreshDisplay() {
    GPIOC->ODR |= MATRIX_OE;  //Turn OE OFF (high)
    GPIOC->ODR |= MATRIX_LAT; //Enable latch to send PREVIOUS row of data

    //Tell the matrix which row to light by decomposing the "row"
    //variable into 4 bits
    GPIOC->ODR = (GPIOC->ODR & ~MATRIX_ROWS) |
            ((row & 0x1) << 6)         |  //Output A
            (((row >> 1) & 0x1) << 7)  |  //Output B
            (((row >> 2) & 0x1) << 10) |  //Output C
            (((row >> 3) & 0x1) << 11);   //Output D

    uint8_t* buffPtr = &matrixBuffer[row][0][plane];

    //Shift 6 bits (R1, G1, B1, R2, G2, B2) at a time to the display, 32 times for one row
    for (int x = 0; x < WIDTH; x++, buffPtr += 3) {
        //GPIOC->ODR = (GPIOC->ODR & ~MATRIX_LEDS) | matrixBuffer[row][x][plane];
        GPIOC->ODR = (GPIOC->ODR & ~MATRIX_LEDS) | *buffPtr;

        //Clock in the data
        GPIOC->ODR |= MATRIX_CLK;  //CLK high
        GPIOC->ODR &= ~MATRIX_CLK; //CLK low
    }

    //Switch row and plane
    if (++plane >= NUM_PLANES) {
        plane = 0;
        if (++row >= NUM_ROWS) {
            row = 0;
            //toggleCursor();
        }
    }

    GPIOC->ODR &= ~MATRIX_LAT; //Disable latch
    GPIOC->ODR &= ~MATRIX_OE;  //Enable output (low)
}


/**
 * =================================================================
 * DRAWING FUNCTIONS
 * =================================================================
 *  - All pixels are indexed with X, Y values (rather than row, col).
 *  - Pixel (0, 0) is in the TOP LEFT of the screen (much like images).
 */

void drawPixel2(uint8_t x, uint8_t y, uint16_t color) {
    drawPixel(x, y, color);
    //nano_wait(10000000);
}


/**
 * Draws a pixel of a given color at a specified location.
 *  - Color is specified as [xxxx xBGR xBGR xBGR]. This is so that it is
 *    easier to apply these pixels to the ODR.
 *  - Each "BGR" group corresponds to one plane.
 */
void drawPixel(uint8_t x, uint8_t y, uint16_t color) {
    //Check for out of bounds coordinates
    if (x < 0 || x >= WIDTH || y < 0 || y >= NUM_ROWS * 2)
        return;

    uint8_t rowMask = 0x7; //Mask for top-half pixels
    uint8_t rowOffset = 0;

    //Adjust for rows on the bottom of the display
    if (y >= NUM_ROWS) {
        y -= NUM_ROWS;
        rowMask = 0x38;
        rowOffset = 3;
    }

    //volatile uint8_t* buffPtr = &matrixBuffer[y][x][0];
    //volatile uint8_t newValue;

    //Update the buffer with the new pixel values
    for (uint8_t plane = 0; plane < NUM_PLANES; plane++) {

        //Mask off color data for the plane
        uint8_t planeColor = (color >> (4 * plane)) & 0x7;

        //Mask off the plane's RGB values for the specified row
        matrixBuffer[y][x][plane] = (matrixBuffer[y][x][plane] & ~rowMask) |
                (planeColor << rowOffset);
    }
}


/**
 * Fills the entire display with a single color.
 * Color specified as [xxxx xBGR xBGR xBGR].
 */
void fillScreen(uint16_t color) {
    for (uint8_t y = 0; y < NUM_ROWS; y++) {
        for (uint8_t x = 0; x < WIDTH; x++) {
            for (uint8_t plane = 0; plane < NUM_PLANES; plane++) {
                uint8_t planeColor = (color >> (4 * plane)) & 0x7;
                matrixBuffer[y][x][plane] = planeColor | (planeColor << 3);
            }
        }
    }
}


