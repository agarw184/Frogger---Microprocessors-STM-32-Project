/*
 * game.c
 *
 *  Created on: Nov 13, 2019
 *      Author: aarcalg
 */

#include <stdlib.h>
#include <string.h>
#include "stm32f0xx.h"
#include "stm32f0_discovery.h"

#include "display.h"


//Define the colors as constants




void setupGame()
{
    fillScreen(COLOR16_OFF); //Clear the screen
    showWelcomeScreen();
    fillScreen(COLOR16_RED);

}
void showWelcomeScreen() {
    uint16_t welcomeColor = COLOR16_RED;
    uint16_t toColor = COLOR16_YELLOW;
    uint16_t blackColor = COLOR16_GREEN;
    uint16_t boxColor = COLOR16_BLUE;

    uint16_t color = welcomeColor; //Welcome
    drawPixel2(1, 1, color); //W
    drawPixel2(1, 2, color);
    drawPixel2(1, 3, color);
    drawPixel2(1, 4, color);
    drawPixel2(1, 5, color);
    drawPixel2(2, 6, color);
    drawPixel2(3, 5, color);
    drawPixel2(3, 4, color);
    drawPixel2(4, 6, color);
    drawPixel2(5, 5, color);
    drawPixel2(5, 4, color);
    drawPixel2(5, 3, color);
    drawPixel2(5, 2, color);
    drawPixel2(5, 1, color);

    drawPixel2(8, 2, color); //E
    drawPixel2(7, 3, color);
    drawPixel2(9, 3, color);
    drawPixel2(7, 4, color);
    drawPixel2(8, 4, color);
    drawPixel2(9, 4, color);
    drawPixel2(7, 5, color);
    drawPixel2(8, 6, color);
    drawPixel2(9, 6, color);

    drawPixel2(11, 1, color); //L
    drawPixel2(11, 2, color);
    drawPixel2(11, 3, color);
    drawPixel2(11, 4, color);
    drawPixel2(11, 5, color);
    drawPixel2(11, 6, color);

    drawPixel2(15, 3, color); //C
    drawPixel2(14, 3, color);
    drawPixel2(13, 4, color);
    drawPixel2(13, 5, color);
    drawPixel2(14, 6, color);
    drawPixel2(15, 6, color);

    drawPixel2(18, 3, color); //O
    drawPixel2(19, 3, color);
    drawPixel2(17, 4, color);
    drawPixel2(17, 5, color);
    drawPixel2(20, 4, color);
    drawPixel2(20, 5, color);
    drawPixel2(18, 6, color);
    drawPixel2(19, 6, color);

    drawPixel2(23, 3, color); //M
    drawPixel2(25, 3, color);
    drawPixel2(24, 4, color);
    drawPixel2(22, 4, color);
    drawPixel2(22, 5, color);
    drawPixel2(22, 6, color);
    drawPixel2(26, 4, color);
    drawPixel2(26, 5, color);
    drawPixel2(26, 6, color);

    drawPixel2(29, 2, color); //E
    drawPixel2(28, 3, color);
    drawPixel2(30, 3, color);
    drawPixel2(28, 4, color);
    drawPixel2(29, 4, color);
    drawPixel2(30, 4, color);
    drawPixel2(28, 5, color);
    drawPixel2(29, 6, color);
    drawPixel2(30, 6, color);

    color = toColor; //To
    drawPixel2(13, 9, color); //T
    drawPixel2(13, 10, color);
    drawPixel2(13, 11, color);
    drawPixel2(13, 12, color);
    drawPixel2(13, 13, color);
    drawPixel2(13, 14, color);
    drawPixel2(12, 11, color);
    drawPixel2(14, 11, color);

    drawPixel2(17, 11, color); //O
    drawPixel2(18, 11, color);
    drawPixel2(16, 12, color);
    drawPixel2(16, 13, color);
    drawPixel2(19, 12, color);
    drawPixel2(19, 13, color);
    drawPixel2(17, 14, color);
    drawPixel2(18, 14, color);

    color = blackColor; //Black
    drawPixel2(6, 17, color); //B
    drawPixel2(7, 17, color);
    drawPixel2(8, 17, color);
    drawPixel2(6, 18, color);
    drawPixel2(9, 18, color);
    drawPixel2(6, 19, color);
    drawPixel2(7, 19, color);
    drawPixel2(8, 19, color);
    drawPixel2(6, 20, color);
    drawPixel2(9, 20, color);
    drawPixel2(6, 21, color);
    drawPixel2(9, 21, color);
    drawPixel2(6, 22, color);
    drawPixel2(7, 22, color);
    drawPixel2(8, 22, color);

    drawPixel2(11, 17, color); //L
    drawPixel2(11, 18, color);
    drawPixel2(11, 19, color);
    drawPixel2(11, 20, color);
    drawPixel2(11, 21, color);
    drawPixel2(11, 22, color);

    drawPixel2(14, 19, color); //A
    drawPixel2(15, 19, color);
    drawPixel2(13, 20, color);
    drawPixel2(13, 21, color);
    drawPixel2(16, 20, color);
    drawPixel2(16, 21, color);
    drawPixel2(14, 22, color);
    drawPixel2(15, 22, color);
    drawPixel2(17, 22, color);

    drawPixel2(20, 19, color); //C
    drawPixel2(21, 19, color);
    drawPixel2(19, 20, color);
    drawPixel2(19, 21, color);
    drawPixel2(20, 22, color);
    drawPixel2(21, 22, color);

    drawPixel2(23, 18, color); //K
    drawPixel2(23, 19, color);
    drawPixel2(23, 20, color);
    drawPixel2(23, 21, color);
    drawPixel2(23, 22, color);
    drawPixel2(25, 18, color);
    drawPixel2(25, 19, color);
    drawPixel2(24, 20, color);
    drawPixel2(25, 21, color);
    drawPixel2(25, 22, color);

    color = boxColor; //Box!
    drawPixel2(9, 25, color); //B
    drawPixel2(10, 25, color);
    drawPixel2(11, 25, color);
    drawPixel2(9, 26, color);
    drawPixel2(12, 26, color);
    drawPixel2(9, 27, color);
    drawPixel2(10, 27, color);
    drawPixel2(11, 27, color);
    drawPixel2(9, 28, color);
    drawPixel2(12, 28, color);
    drawPixel2(9, 29, color);
    drawPixel2(12, 29, color);
    drawPixel2(9, 30, color);
    drawPixel2(10, 30, color);
    drawPixel2(11, 30, color);

    drawPixel2(15, 27, color); //O
    drawPixel2(16, 27, color);
    drawPixel2(14, 28, color);
    drawPixel2(14, 29, color);
    drawPixel2(17, 28, color);
    drawPixel2(17, 29, color);
    drawPixel2(15, 30, color);
    drawPixel2(16, 30, color);

    drawPixel2(19, 26, color); //X
    drawPixel2(19, 27, color);
    drawPixel2(21, 26, color);
    drawPixel2(21, 27, color);
    drawPixel2(20, 28, color);
    drawPixel2(19, 29, color);
    drawPixel2(19, 30, color);
    drawPixel2(21, 29, color);
    drawPixel2(21, 30, color);

    drawPixel2(23, 25, color); //!
    drawPixel2(23, 26, color);
    drawPixel2(23, 27, color);
    drawPixel2(23, 28, color);
    drawPixel2(23, 30, color);
}
