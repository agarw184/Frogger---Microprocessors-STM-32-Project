/**
  ******************************************************************************
  * @file    main.c
  * @author  Ac6
  * @version V1.0
  * @date    01-December-2013
  * @brief   Default main function.
  ******************************************************************************
*/


//Standard libraries for C/STM32
#include "stm32f0xx.h"
#include "stm32f0_discovery.h"

//Project-specific libraries
//#include "setup.h"
#include "display.h"




/**
 * Update the LED matrix display.
 */
void TIM3_IRQHandler() {
    refreshDisplay();
    TIM3->SR &= ~TIM_SR_UIF; //Acknowledge interrupt
}


int main(void)
{
    //1) Configure GPIO ports for Matrix Pins (MODER -> output)
    //2) Create a buffer pointer reserve mem
    //3) Fill buffer pointer with data we want
    //4) refresh display

    setupGPIO();
    initMatrix(); //Call before setupTimers() to initialize matrix values before sending any data
    setupTimers();
    setupGame();

    //fillScreen(COLOR16_RED);

	for(;;);
}
