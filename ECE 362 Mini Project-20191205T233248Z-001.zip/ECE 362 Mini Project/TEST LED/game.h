#include <stdio.h> //Needed to define uint8_t type.


//Game test function declarations
void setupGame();
void showWelcomeScreen();
