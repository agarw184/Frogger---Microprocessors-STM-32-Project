#include <stdio.h> //Needed to define uint8_t type.

// Assign GPIO port names to values
#define MATRIX_R1   0x1    //PC0
#define MATRIX_G1   0x2    //PC1
#define MATRIX_B1   0x4    //PC2
#define MATRIX_R2   0x8    //PC3
#define MATRIX_G2   0x10   //PC4
#define MATRIX_B2   0x20   //PC5
#define MATRIX_A    0x40   //PC6
#define MATRIX_B    0x80   //PC7
#define MATRIX_C    0x400  //PC10
#define MATRIX_D    0x800  //PC11
#define MATRIX_CLK  0x2000 //PC13
#define MATRIX_LAT  0x4000 //PC14
#define MATRIX_OE   0x1000 //PC12
#define MATRIX_LEDS 0x3F   //PC0-PC5
#define MATRIX_ROWS 0xCC0  //PC6, 7, 10, 11

/**
 * Define 4-bit colors. Format: xBGR
 */
#define COLOR3_OFF     0x0
#define COLOR3_RED     0x1
#define COLOR3_GREEN   0x2
#define COLOR3_YELLOW  0x3
#define COLOR3_BLUE    0x4
#define COLOR3_MAGENTA 0x5
#define COLOR3_CYAN    0x6
#define COLOR3_WHITE   0x7

/**
 * Define 16-bit colors. Format: xxxx xBGR xBGR xBGR
 */
#define COLOR16_OFF          0x000
#define COLOR16_WHITE        0x777
#define COLOR16_GRAY         0x700
#define COLOR16_DARK_RED     0x100
#define COLOR16_RED          0x111
#define COLOR16_LIGHT_RED    0x116
#define COLOR16_MUTED_PINK   0x153
#define COLOR16_LIGHT_PINK   0x345
#define COLOR16_PINK         0x557
#define COLOR16_HOT_PINK     0x114
#define COLOR16_MAGENTA      0x555
#define COLOR16_DARK_MAGENTA 0x500
#define COLOR16_PURPLE       0x441
#define COLOR16_LIGHT_PURPLE 0x556
#define COLOR16_LIGHT_BLUE   0x667
#define COLOR16_CYAN         0x666
#define COLOR16_TURQUOISE    0x226
#define COLOR16_DARK_CYAN    0x600
#define COLOR16_BLUE         0x444
#define COLOR16_DARK_BLUE    0x400
#define COLOR16_AQUA         0x406
#define COLOR16_TEAL         0x224
#define COLOR16_SEA_FOAM_GRN 0x243
#define COLOR16_DARK_GREEN   0x200
#define COLOR16_GREEN        0x222
#define COLOR16_GREEN_YELLOW 0x223
#define COLOR16_YELLOW_GREEN 0x332
#define COLOR16_YELLOW       0x333
#define COLOR16_DARK_YELLOW  0x300
#define COLOR16_ORANGE       0x113
#define COLOR16_DARK_ORANGE  0x103
#define COLOR16_TAN          0x336
#define COLOR16_PEACH        0x371


/**
 * The width of the display, in pixels (hardware defined).
 */
#define WIDTH 32

/**
 * The number of rows to scan (hardware defined).
 * The actual display height is twice this (32 rows).
 */
#define NUM_ROWS 16

/**
 * The number of planes available to display colors.
 * We can use up to 4, but this introduces unnecessary complexity,
 * so we will stick with 3.
 */
#define NUM_PLANES 3

/**
 * The current row being displayed (0-15).
 * In reality, both this row and row (this + 16) are displayed.
 */
uint8_t row;

/**
 * The current plane being displayed (0-2).
 */
uint8_t plane;

/**
 * The buffer that stores the image data to be displayed.
 * - The "3" in the third dimension is there because we need 3 bytes to
 *   represent 6 bits of color in 3 planes (6 bits / plane).
 * - We can actually express 4 planes of 6 color bits in 3 bytes, but this
 *   becomes unnecessarily complicated for our purposes.
 */
uint8_t matrixBuffer[NUM_ROWS][WIDTH][3];

void initMatrix();
void initPorts();
void refreshDisplay();
void setupGPIO();
void initMatrix();
void setupTimers();
void fillScreen(uint16_t);
void drawPixel(uint8_t , uint8_t , uint16_t);



