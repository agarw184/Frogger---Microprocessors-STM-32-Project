/*
 * setup.c
 *
 *  Created on: Nov 13, 2019
 *      Author: aarcalg
 */
#include "stm32f0xx.h"
#include "stm32f0_discovery.h"
//#include "setup.h"

void setupGPIO();
void setupTimer3();
//User timer 3 to refresh display
/**
 * Enable TIM3 to continually trigger the TIM3 interrupt to refresh
 * the LED matrix display.
 */

void setupGPIO()
{
    //Setup GPIOC (LED matrix, PC0-PC12)
    RCC->AHBENR |= RCC_AHBENR_GPIOCEN;  //Enable clock to GPIOC
    GPIOC->MODER = (GPIOC->MODER & 0xC00F0000) | 0x15505555; //PC0-12 output
    GPIOC->PUPDR = (GPIOC->PUPDR & 0xC00F0000) | 0x15505555; //Pull-up (has no effect)
}


void setupTimer3() {
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN; //Enable clock to TIM3

    //Configure for up counting and edge-aligned
    TIM3->CR1 &= ~(TIM_CR1_CMS | TIM_CR1_DIR);
    TIM3->PSC = 48 - 1; //Run TIM2 at 1 MHz
    TIM3->ARR = 200; //Trigger every 0.2 msec

    TIM3->DIER |= TIM_DIER_UIE;  //Enable update interrupts

    //Enable TIM3 and its interrupt
    TIM3->CR1 |= TIM_CR1_CEN;
    NVIC->ISER[0] = 1 << TIM3_IRQn;
}

/**
 * Configure timer 3.
 */
void setupTimers()
{
    setupTimer3();
}

